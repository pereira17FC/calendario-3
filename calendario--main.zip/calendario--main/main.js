
console.log(Date());